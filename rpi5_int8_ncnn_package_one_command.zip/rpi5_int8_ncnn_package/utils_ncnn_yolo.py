#!/usr/bin/env python3
"""
utils_ncnn_yolo.py
Utilities for YOLO INT8 NCNN inference on Raspberry Pi 5.

Designed for Ultralytics YOLO11 NCNN exports whose output is already decoded:
    [N, 4 + nc] = [cx, cy, w, h, class_scores...]
For the provided model, nc=4 and N=10164 at imgsz=704.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None

try:
    import ncnn  # type: ignore
except Exception as e:  # pragma: no cover
    ncnn = None
    NCNN_IMPORT_ERROR = e
else:
    NCNN_IMPORT_ERROR = None

CLASS_NAMES = ["HDPE", "ECAL", "PET", "Mixed_Plastic"]
NUM_CLASSES = len(CLASS_NAMES)
# BGR colors for OpenCV drawing
CLASS_COLORS = [
    (46, 204, 113),   # HDPE
    (52, 152, 219),   # ECAL
    (241, 196, 15),   # PET
    (231, 76, 60),    # Mixed_Plastic
]


def parse_ncnn_param(param_path: str | Path) -> Dict[str, Any]:
    """Very small NCNN param parser to list likely input/output blobs."""
    p = Path(param_path)
    info: Dict[str, Any] = {
        "param_path": str(p),
        "exists": p.exists(),
        "inputs": [],
        "outputs_guess": [],
        "layers": [],
        "blob_consumers": {},
        "blob_producers": {},
    }
    if not p.exists():
        return info

    lines = p.read_text(errors="ignore").splitlines()
    if len(lines) >= 2:
        info["magic"] = lines[0].strip()
        info["counts"] = lines[1].strip()

    produced = []
    consumed = []
    layers = []
    for line in lines[2:]:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        layer_type, layer_name = parts[0], parts[1]
        try:
            n_in, n_out = int(parts[2]), int(parts[3])
        except Exception:
            continue
        in_blobs = parts[4:4 + n_in]
        out_blobs = parts[4 + n_in:4 + n_in + n_out]
        layers.append({
            "type": layer_type,
            "name": layer_name,
            "inputs": in_blobs,
            "outputs": out_blobs,
        })
        if layer_type.lower() == "input":
            info["inputs"].extend(out_blobs)
        for b in in_blobs:
            consumed.append(b)
            info["blob_consumers"].setdefault(b, []).append(layer_name)
        for b in out_blobs:
            produced.append(b)
            info["blob_producers"][b] = layer_name

    # Blobs produced but never consumed are model outputs. If none, use last layer outputs.
    consumed_set = set(consumed)
    outputs = [b for b in produced if b not in consumed_set]
    if not outputs and layers:
        outputs = layers[-1]["outputs"]
    info["outputs_guess"] = outputs
    info["layers"] = layers
    return info


def cpu_temp_c() -> Optional[float]:
    """Return Raspberry Pi CPU temperature if available."""
    candidates = [
        Path("/sys/class/thermal/thermal_zone0/temp"),
        Path("/sys/class/hwmon/hwmon0/temp1_input"),
    ]
    for p in candidates:
        try:
            if p.exists():
                raw = p.read_text().strip()
                v = float(raw)
                return v / 1000.0 if v > 200 else v
        except Exception:
            pass
    return None


def ram_percent() -> Optional[float]:
    if psutil is None:
        return None
    try:
        return float(psutil.virtual_memory().percent)
    except Exception:
        return None


def cpu_percent_nonblocking() -> Optional[float]:
    if psutil is None:
        return None
    try:
        return float(psutil.cpu_percent(interval=None))
    except Exception:
        return None


def summarize_latencies(values: Sequence[float]) -> Dict[str, float]:
    arr = np.asarray(list(values), dtype=np.float64)
    if arr.size == 0:
        return {k: 0.0 for k in ["mean", "median", "p50", "p90", "p95", "p99", "min", "max", "std"]}
    return {
        "mean": float(np.mean(arr)),
        "median": float(np.median(arr)),
        "p50": float(np.percentile(arr, 50)),
        "p90": float(np.percentile(arr, 90)),
        "p95": float(np.percentile(arr, 95)),
        "p99": float(np.percentile(arr, 99)),
        "min": float(np.min(arr)),
        "max": float(np.max(arr)),
        "std": float(np.std(arr)),
    }


def list_images(path: str | Path, recursive: bool = False) -> List[Path]:
    p = Path(path)
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
    if p.is_file() and p.suffix.lower() in exts:
        return [p]
    if not p.exists():
        return []
    iterator = p.rglob("*") if recursive else p.glob("*")
    return sorted([x for x in iterator if x.is_file() and x.suffix.lower() in exts])


def letterbox(
    img: np.ndarray,
    new_shape: int | Tuple[int, int] = 640,
    color: Tuple[int, int, int] = (114, 114, 114),
) -> Tuple[np.ndarray, float, Tuple[float, float]]:
    """Resize image while keeping aspect ratio. Returns image, ratio, (dw, dh)."""
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)
    h0, w0 = img.shape[:2]
    new_h, new_w = int(new_shape[0]), int(new_shape[1])
    r = min(new_h / h0, new_w / w0)
    resized_w, resized_h = int(round(w0 * r)), int(round(h0 * r))
    dw, dh = (new_w - resized_w) / 2.0, (new_h - resized_h) / 2.0

    if (w0, h0) != (resized_w, resized_h):
        img = cv2.resize(img, (resized_w, resized_h), interpolation=cv2.INTER_LINEAR)

    top = int(round(dh - 0.1))
    bottom = int(round(dh + 0.1))
    left = int(round(dw - 0.1))
    right = int(round(dw + 0.1))
    out = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)
    return out, r, (float(left), float(top))


def xywh_to_xyxy(boxes: np.ndarray) -> np.ndarray:
    out = boxes.copy()
    out[:, 0] = boxes[:, 0] - boxes[:, 2] / 2.0
    out[:, 1] = boxes[:, 1] - boxes[:, 3] / 2.0
    out[:, 2] = boxes[:, 0] + boxes[:, 2] / 2.0
    out[:, 3] = boxes[:, 1] + boxes[:, 3] / 2.0
    return out


def clip_boxes(boxes: np.ndarray, w: int, h: int) -> np.ndarray:
    boxes[:, [0, 2]] = boxes[:, [0, 2]].clip(0, w - 1)
    boxes[:, [1, 3]] = boxes[:, [1, 3]].clip(0, h - 1)
    return boxes


def nms_numpy(boxes: np.ndarray, scores: np.ndarray, iou_thresh: float) -> List[int]:
    """Classical NMS on one class."""
    if boxes.size == 0:
        return []
    x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    areas = np.maximum(0, x2 - x1) * np.maximum(0, y2 - y1)
    order = scores.argsort()[::-1]
    keep: List[int] = []
    while order.size > 0:
        i = int(order[0])
        keep.append(i)
        if order.size == 1:
            break
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        inter = np.maximum(0, xx2 - xx1) * np.maximum(0, yy2 - yy1)
        union = areas[i] + areas[order[1:]] - inter + 1e-9
        iou = inter / union
        order = order[1:][iou <= iou_thresh]
    return keep


def class_wise_nms(
    boxes: np.ndarray,
    scores: np.ndarray,
    class_ids: np.ndarray,
    iou_thresh: float,
    max_det: int = 300,
) -> List[int]:
    keep_all: List[int] = []
    for cid in np.unique(class_ids):
        idxs = np.where(class_ids == cid)[0]
        keep_local = nms_numpy(boxes[idxs], scores[idxs], iou_thresh)
        keep_all.extend([int(idxs[i]) for i in keep_local])
    keep_all = sorted(keep_all, key=lambda i: float(scores[i]), reverse=True)[:max_det]
    return keep_all


def mat_to_numpy(mat: Any) -> np.ndarray:
    """Convert ncnn.Mat to numpy array robustly."""
    arr = np.array(mat)
    # Some ncnn builds expose w/h/c but np.array returns flattened. Use shape if possible.
    try:
        w, h, c = int(mat.w), int(mat.h), int(mat.c)
        if arr.ndim == 1 and w * max(h, 1) * max(c, 1) == arr.size:
            if c > 1 and h > 1:
                arr = arr.reshape(c, h, w)
            elif h > 1:
                arr = arr.reshape(h, w)
            else:
                arr = arr.reshape(w)
    except Exception:
        pass
    return arr


def normalize_yolo_output(raw: np.ndarray, nc: int = NUM_CLASSES) -> np.ndarray:
    """Return output as [N, 4+nc] or [N, 5+nc] if objectness exists."""
    arr = np.asarray(raw, dtype=np.float32)
    arr = np.squeeze(arr)
    ch_no_obj = 4 + nc
    ch_obj = 5 + nc

    if arr.ndim == 2:
        # [N,C]
        if arr.shape[1] in (ch_no_obj, ch_obj):
            return arr
        # [C,N]
        if arr.shape[0] in (ch_no_obj, ch_obj):
            return arr.T
    elif arr.ndim == 3:
        # [1,N,C]
        if arr.shape[0] == 1 and arr.shape[2] in (ch_no_obj, ch_obj):
            return arr[0]
        # [1,C,N]
        if arr.shape[0] == 1 and arr.shape[1] in (ch_no_obj, ch_obj):
            return arr[0].T
        # [C,H,W] flatten spatial
        if arr.shape[0] in (ch_no_obj, ch_obj):
            return arr.reshape(arr.shape[0], -1).T
        # [H,W,C]
        if arr.shape[-1] in (ch_no_obj, ch_obj):
            return arr.reshape(-1, arr.shape[-1])

    flat = arr.reshape(-1)
    for ch in (ch_no_obj, ch_obj):
        if flat.size % ch == 0:
            return flat.reshape(-1, ch)
    raise ValueError(
        f"Cannot parse NCNN output shape {raw.shape}; flat={flat.size}, "
        f"expected channels {ch_no_obj} or {ch_obj}."
    )


class NCNNDetector:
    """NCNN YOLO detector wrapper."""

    def __init__(
        self,
        param_path: str | Path,
        bin_path: str | Path,
        imgsz: int = 704,
        num_threads: int = 4,
        use_vulkan: bool = False,
        input_blob: str = "in0",
        output_blob: str = "out0",
        nc: int = NUM_CLASSES,
    ):
        if ncnn is None:
            raise ImportError(
                "Python package 'ncnn' is not installed or failed to import. "
                f"Original error: {NCNN_IMPORT_ERROR}"
            )
        self.ncnn = ncnn
        self.param_path = str(param_path)
        self.bin_path = str(bin_path)
        self.imgsz = int(imgsz)
        self.num_threads = int(num_threads)
        self.use_vulkan = bool(use_vulkan)
        self.nc = int(nc)

        info = parse_ncnn_param(param_path)
        self.param_info = info
        if input_blob == "auto":
            input_blob = info.get("inputs", ["in0"])[0] if info.get("inputs") else "in0"
        if output_blob == "auto":
            outs = info.get("outputs_guess") or ["out0"]
            output_blob = outs[0]
        self.input_blob = input_blob
        self.output_blob = output_blob

        self.net = ncnn.Net()
        try:
            self.net.opt.num_threads = self.num_threads
            self.net.opt.use_vulkan_compute = self.use_vulkan
            self.net.opt.lightmode = True
        except Exception:
            pass

        ret = self.net.load_param(self.param_path)
        if ret != 0:
            raise RuntimeError(f"ncnn load_param failed with ret={ret}: {self.param_path}")
        ret = self.net.load_model(self.bin_path)
        if ret != 0:
            raise RuntimeError(f"ncnn load_model failed with ret={ret}: {self.bin_path}")

    def _preprocess(self, img_bgr: np.ndarray) -> Tuple[Any, float, Tuple[float, float], Tuple[int, int]]:
        orig_h, orig_w = img_bgr.shape[:2]
        lb, ratio, pad = letterbox(img_bgr, self.imgsz)
        # Input exported from Ultralytics usually expects RGB normalized 0-1.
        mat = self.ncnn.Mat.from_pixels(
            lb,
            self.ncnn.Mat.PixelType.PIXEL_BGR2RGB,
            self.imgsz,
            self.imgsz,
        )
        mat.substract_mean_normalize([0.0, 0.0, 0.0], [1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0])
        return mat, ratio, pad, (orig_w, orig_h)

    def infer(
        self,
        img_bgr: np.ndarray,
        conf_thresh: float = 0.25,
        iou_thresh: float = 0.45,
        max_det: int = 300,
    ) -> Tuple[List[Dict[str, Any]], Dict[str, float]]:
        t0 = time.perf_counter()
        mat, ratio, (pad_x, pad_y), (orig_w, orig_h) = self._preprocess(img_bgr)
        t1 = time.perf_counter()

        ex = self.net.create_extractor()
        try:
            ex.set_light_mode(True)
            ex.set_num_threads(self.num_threads)
        except Exception:
            pass
        ret = ex.input(self.input_blob, mat)
        if ret != 0:
            raise RuntimeError(f"ncnn input failed ret={ret} blob={self.input_blob}")
        ret, out = ex.extract(self.output_blob)
        if ret != 0:
            raise RuntimeError(f"ncnn extract failed ret={ret} blob={self.output_blob}")
        t2 = time.perf_counter()

        raw = mat_to_numpy(out)
        preds = normalize_yolo_output(raw, self.nc)  # [N, 4+nc] or [N,5+nc]
        dets = self._postprocess(preds, ratio, (pad_x, pad_y), (orig_w, orig_h), conf_thresh, iou_thresh, max_det)
        t3 = time.perf_counter()

        timing = {
            "preprocess_ms": (t1 - t0) * 1000.0,
            "inference_ms": (t2 - t1) * 1000.0,
            "postprocess_ms": (t3 - t2) * 1000.0,
            "total_ms": (t3 - t0) * 1000.0,
        }
        return dets, timing

    def _postprocess(
        self,
        preds: np.ndarray,
        ratio: float,
        pad: Tuple[float, float],
        orig_shape: Tuple[int, int],
        conf_thresh: float,
        iou_thresh: float,
        max_det: int,
    ) -> List[Dict[str, Any]]:
        if preds.size == 0:
            return []
        ch = preds.shape[1]
        boxes_xywh = preds[:, :4].astype(np.float32)

        if ch == 4 + self.nc:
            cls_scores = preds[:, 4:4 + self.nc].astype(np.float32)
            class_ids = np.argmax(cls_scores, axis=1)
            scores = cls_scores[np.arange(cls_scores.shape[0]), class_ids]
        elif ch == 5 + self.nc:
            obj = preds[:, 4].astype(np.float32)
            cls_scores = preds[:, 5:5 + self.nc].astype(np.float32)
            class_ids = np.argmax(cls_scores, axis=1)
            scores = obj * cls_scores[np.arange(cls_scores.shape[0]), class_ids]
        else:
            raise ValueError(f"Unexpected prediction channels {ch}; expected {4+self.nc} or {5+self.nc}")

        # Heuristic: if coords are normalized, scale to network input size.
        if np.nanmax(boxes_xywh[:, :4]) <= 2.0:
            boxes_xywh[:, :4] *= float(self.imgsz)

        mask = np.isfinite(scores) & (scores >= conf_thresh)
        mask &= np.all(np.isfinite(boxes_xywh), axis=1)
        boxes_xywh = boxes_xywh[mask]
        scores = scores[mask]
        class_ids = class_ids[mask]
        if boxes_xywh.size == 0:
            return []

        boxes = xywh_to_xyxy(boxes_xywh)
        # remove letterbox padding then scale back to original image
        boxes[:, [0, 2]] = (boxes[:, [0, 2]] - pad[0]) / max(ratio, 1e-9)
        boxes[:, [1, 3]] = (boxes[:, [1, 3]] - pad[1]) / max(ratio, 1e-9)
        orig_w, orig_h = orig_shape
        boxes = clip_boxes(boxes, orig_w, orig_h)

        # Filter tiny/invalid boxes after scaling.
        wh = boxes[:, 2:4] - boxes[:, 0:2]
        valid = (wh[:, 0] > 1.0) & (wh[:, 1] > 1.0)
        boxes = boxes[valid]
        scores = scores[valid]
        class_ids = class_ids[valid]
        if boxes.size == 0:
            return []

        keep = class_wise_nms(boxes, scores, class_ids, iou_thresh, max_det=max_det)
        results: List[Dict[str, Any]] = []
        for i in keep:
            cid = int(class_ids[i])
            results.append({
                "bbox": [float(x) for x in boxes[i].tolist()],
                "score": float(scores[i]),
                "class_id": cid,
                "class_name": CLASS_NAMES[cid] if 0 <= cid < len(CLASS_NAMES) else str(cid),
            })
        return results


def draw_detections(img_bgr: np.ndarray, detections: List[Dict[str, Any]]) -> np.ndarray:
    out = img_bgr.copy()
    for d in detections:
        x1, y1, x2, y2 = [int(round(v)) for v in d["bbox"]]
        cid = int(d.get("class_id", 0))
        score = float(d.get("score", 0.0))
        color = CLASS_COLORS[cid % len(CLASS_COLORS)]
        label = f"{d.get('class_name', cid)} {score:.2f}"
        cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
        (tw, th), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        y_text = max(0, y1 - th - baseline - 2)
        cv2.rectangle(out, (x1, y_text), (x1 + tw + 4, y_text + th + baseline + 4), color, -1)
        cv2.putText(out, label, (x1 + 2, y_text + th + 1), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    return out


def draw_hud(img_bgr: np.ndarray, lines: Sequence[str]) -> np.ndarray:
    out = img_bgr.copy()
    x, y = 10, 25
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = 0.6
    thickness = 2
    line_h = 24
    max_w = 0
    for line in lines:
        (tw, _), _ = cv2.getTextSize(str(line), font, scale, thickness)
        max_w = max(max_w, tw)
    cv2.rectangle(out, (5, 5), (20 + max_w, 12 + line_h * len(lines)), (0, 0, 0), -1)
    cv2.rectangle(out, (5, 5), (20 + max_w, 12 + line_h * len(lines)), (255, 255, 255), 1)
    for i, line in enumerate(lines):
        cv2.putText(out, str(line), (x, y + i * line_h), font, scale, (255, 255, 255), thickness, cv2.LINE_AA)
    return out
