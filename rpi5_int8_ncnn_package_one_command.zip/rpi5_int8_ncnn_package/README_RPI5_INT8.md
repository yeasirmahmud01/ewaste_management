# Raspberry Pi 5 INT8 NCNN Runner

This package runs a YOLO INT8 NCNN model on Raspberry Pi 5 for:

1. model verification
2. single-image inference
3. bulk benchmark testing
4. live USB/Pi camera demo

Included model files:

- `model.ncnn.param`
- `model.ncnn.bin`
- `model_int8.table`

The `.table` file is logged for calibration provenance. NCNN runtime normally uses the already-quantized `.param` and `.bin`; the table is usually not loaded at runtime.

## Classes

The script assumes 4 classes:

0. HDPE
1. ECAL
2. PET
3. Mixed_Plastic

## Expected model shape

The provided `model.ncnn.param` ends with decoded output `out0` and has 4 classes. For `imgsz=704`, the model likely produces:

- output locations: `88*88 + 44*44 + 22*22 = 10164`
- output channels: `4 + 4 = 8`
- decoded format: `[cx, cy, w, h, class_scores...]`

Run `verify` first to confirm this on your Raspberry Pi.

---

## 1. Install on Raspberry Pi 5

Copy this folder to the Pi, then run:

```bash
cd rpi5_int8_ncnn_package
chmod +x install_rpi.sh
./install_rpi.sh
source .venv/bin/activate
```

If `ncnn` does not install/import from pip, you need to build NCNN Python bindings manually. The rest of the package will be ready once `import ncnn` works.

---

## 2. Verify model

```bash
python run_int8.py verify \
  --param model.ncnn.param \
  --bin model.ncnn.bin \
  --table model_int8.table \
  --imgsz 704 \
  --threads 4
```

The verify command prints:

- detected input blob
- detected output blob
- raw output shape
- implied number of anchors
- dummy inference latency
- parser sanity status

If blob detection fails, manually try:

```bash
python run_int8.py verify --param model.ncnn.param --bin model.ncnn.bin --imgsz 704 --input-blob in0 --output-blob out0
```

---

## 3. Single image test

```bash
python run_int8.py image \
  --param model.ncnn.param \
  --bin model.ncnn.bin \
  --table model_int8.table \
  --image test.jpg \
  --imgsz 704 \
  --conf 0.25 \
  --iou 0.45 \
  --save
```

Outputs go to `demo_outputs/`:

- annotated image
- JSON detections and timing

---

## 4. Bulk benchmark testing

Example for breaking-point testing:

```bash
python run_int8.py bulk \
  --param model.ncnn.param \
  --bin model.ncnn.bin \
  --table model_int8.table \
  --source /home/pi/test_images \
  --imgsz 704 \
  --bulk-sizes 10 100 500 1000 \
  --warmup 10 \
  --threads 4 \
  --conf 0.25 \
  --iou 0.45 \
  --save-plots \
  --save-annotated \
  --max-save-annotated 50
```

If the folder contains fewer images than a requested bulk size, the script repeats images and clearly reports that it looped images.

Bulk outputs:

- `benchmark_outputs/benchmark_summary.csv`
- `benchmark_outputs/benchmark_per_image.csv`
- `benchmark_outputs/benchmark_summary.json`
- per-bulk folders like `bulk_10/`, `bulk_100/`
- plots as PNG and SVG

Measured metrics:

- preprocess latency
- inference latency
- postprocess latency
- total latency
- FPS
- p50/p90/p95/p99 latency
- CPU temperature
- RAM usage
- detection count per image
- class detection counts
- confidence distribution

Breaking point defaults:

- FPS below 10
- p95 latency above 150 ms
- CPU temperature above 80°C
- RAM usage above 85%

Customize:

```bash
--fps-threshold 10 --latency-threshold-ms 150 --temp-threshold-c 80 --ram-threshold-percent 85
```

---

## 5. Live USB camera demo

```bash
python run_int8.py live \
  --param model.ncnn.param \
  --bin model.ncnn.bin \
  --table model_int8.table \
  --camera 0 \
  --imgsz 704 \
  --threads 4 \
  --conf 0.25 \
  --iou 0.45 \
  --display
```

Keyboard controls:

- `q` quit
- `s` save snapshot
- `p` pause/resume

Headless mode:

```bash
python run_int8.py live --param model.ncnn.param --bin model.ncnn.bin --camera 0 --imgsz 704 --headless --duration 60
```

---

## 6. Live Raspberry Pi Camera Module demo

Install Picamera2 if needed:

```bash
sudo apt install -y python3-picamera2
```

Run:

```bash
python run_int8.py live \
  --param model.ncnn.param \
  --bin model.ncnn.bin \
  --picamera \
  --imgsz 704 \
  --display
```

---

## 7. Live outputs

Live mode saves to `live_outputs/`:

- `live_log.csv`
- `live_summary.json`
- `live_fps_over_time.png/svg`
- `live_latency_over_time.png/svg`
- CPU/RAM plots if available
- optional snapshots
- optional video

---

## 8. Troubleshooting

### `ModuleNotFoundError: No module named 'ncnn'`

The Python NCNN wheel may not be available for your Raspberry Pi OS/Python version. Options:

1. Try a supported Python version.
2. Build NCNN with Python bindings from source.
3. Use a C++ NCNN runner if Python binding remains unavailable.

### Output shape mismatch

Run verify and inspect:

```bash
python run_int8.py verify --param model.ncnn.param --bin model.ncnn.bin --imgsz 704
```

If output shape does not parse, try manual blobs:

```bash
--input-blob in0 --output-blob out0
```

If channels are not 8, the model may not be the expected 4-class decoded export.

### No detections

Try lower confidence:

```bash
--conf 0.10
```

Also verify preprocessing. The script uses BGR to RGB and normalization `1/255`, which matches typical Ultralytics export.

### Very low FPS

Try:

```bash
--threads 4
--imgsz 640
```

Only use `--imgsz 640` if the model was exported for dynamic or compatible input. The provided model appears to be exported for 704.

### Pi overheats

Use cooling, reduce camera resolution, lower input size if compatible, or reduce continuous live duration.

### INT8 is slower than expected

Report it honestly. INT8 speed depends on NCNN operator support, CPU instructions, memory bandwidth, and whether the model is truly optimized for the target backend.

---

## 9. Recommended thesis benchmark commands

Bulk stress test:

```bash
python run_int8.py bulk --param model.ncnn.param --bin model.ncnn.bin --table model_int8.table --source test_images --imgsz 704 --bulk-sizes 10 100 500 1000 --save-plots --save-annotated
```

Live 60-second benchmark:

```bash
python run_int8.py live --param model.ncnn.param --bin model.ncnn.bin --table model_int8.table --camera 0 --imgsz 704 --headless --duration 60
```

Live demo with display:

```bash
python run_int8.py live --param model.ncnn.param --bin model.ncnn.bin --table model_int8.table --camera 0 --imgsz 704 --display
```
