ONE-COMMAND USE
===============

After copying this folder to Raspberry Pi:

1) First time only:
   bash go.sh setup

2) Verify model:
   bash go.sh verify

3) Single image:
   bash go.sh image test.jpg

4) Bulk benchmark:
   bash go.sh bulk test_images

5) USB camera live demo:
   bash go.sh live

6) SSH/headless USB camera test for 60 seconds:
   bash go.sh live-headless

7) Pi Camera Module:
   bash go.sh picam

8) Pi Camera Module headless:
   bash go.sh picam-headless

Outputs:
- demo_outputs/ for single image
- benchmark_outputs/ for bulk test CSV/graphs
- live_outputs/ for camera logs/graphs/video
