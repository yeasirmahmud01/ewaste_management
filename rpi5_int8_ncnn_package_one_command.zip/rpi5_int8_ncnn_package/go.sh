#!/usr/bin/env bash
# One-command launcher for Raspberry Pi 5 INT8 NCNN package.
# Usage:
#   bash go.sh setup
#   bash go.sh verify
#   bash go.sh image test.jpg
#   bash go.sh bulk test_images
#   bash go.sh live
#   bash go.sh live-headless
set -e

CMD="$1"
ARG1="$2"

PARAM="model.ncnn.param"
BIN="model.ncnn.bin"
TABLE="model_int8.table"
IMGSZ="704"
THREADS="4"
CONF="0.25"
IOU="0.45"

if [ -z "$CMD" ]; then
  echo "Usage: bash go.sh {setup|verify|image IMAGE|bulk FOLDER|live|live-headless|picam|picam-headless}"
  exit 1
fi

# Activate virtual environment when present.
if [ -d ".venv" ]; then
  source .venv/bin/activate
fi

case "$CMD" in
  setup)
    chmod +x install_rpi.sh
    ./install_rpi.sh
    echo ""
    echo "Setup finished. Now run: bash go.sh verify"
    ;;

  verify)
    python run_int8.py verify \
      --param "$PARAM" --bin "$BIN" --table "$TABLE" \
      --imgsz "$IMGSZ" --threads "$THREADS"
    ;;

  image)
    if [ -z "$ARG1" ]; then
      echo "Usage: bash go.sh image path/to/image.jpg"
      exit 1
    fi
    python run_int8.py image \
      --param "$PARAM" --bin "$BIN" --table "$TABLE" \
      --image "$ARG1" --imgsz "$IMGSZ" --threads "$THREADS" \
      --conf "$CONF" --iou "$IOU" --save
    ;;

  bulk)
    if [ -z "$ARG1" ]; then
      echo "Usage: bash go.sh bulk path/to/images_folder"
      exit 1
    fi
    python run_int8.py bulk \
      --param "$PARAM" --bin "$BIN" --table "$TABLE" \
      --source "$ARG1" --imgsz "$IMGSZ" --threads "$THREADS" \
      --conf "$CONF" --iou "$IOU" \
      --bulk-sizes 10 100 500 1000 \
      --warmup 10 --save-plots --save-annotated --max-save-annotated 50
    ;;

  live)
    python run_int8.py live \
      --param "$PARAM" --bin "$BIN" --table "$TABLE" \
      --camera 0 --imgsz "$IMGSZ" --threads "$THREADS" \
      --conf "$CONF" --iou "$IOU" --display
    ;;

  live-headless)
    python run_int8.py live \
      --param "$PARAM" --bin "$BIN" --table "$TABLE" \
      --camera 0 --imgsz "$IMGSZ" --threads "$THREADS" \
      --conf "$CONF" --iou "$IOU" --headless --duration 60
    ;;

  picam)
    python run_int8.py live \
      --param "$PARAM" --bin "$BIN" --table "$TABLE" \
      --picamera --imgsz "$IMGSZ" --threads "$THREADS" \
      --conf "$CONF" --iou "$IOU" --display
    ;;

  picam-headless)
    python run_int8.py live \
      --param "$PARAM" --bin "$BIN" --table "$TABLE" \
      --picamera --imgsz "$IMGSZ" --threads "$THREADS" \
      --conf "$CONF" --iou "$IOU" --headless --duration 60
    ;;

  *)
    echo "Unknown command: $CMD"
    echo "Usage: bash go.sh {setup|verify|image IMAGE|bulk FOLDER|live|live-headless|picam|picam-headless}"
    exit 1
    ;;
esac
