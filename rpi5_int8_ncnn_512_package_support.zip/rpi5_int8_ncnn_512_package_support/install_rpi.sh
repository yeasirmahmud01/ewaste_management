#!/usr/bin/env bash
set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

echo "[1/6] Updating apt packages..."
sudo apt update

echo "[2/6] Installing system dependencies..."
sudo apt install -y python3 python3-venv python3-pip python3-opencv libopencv-dev \
    libopenblas-dev libomp-dev libprotobuf-dev protobuf-compiler git cmake build-essential

echo "[3/6] Creating virtual environment..."
python3 -m venv .venv --system-site-packages
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel

echo "[4/6] Installing Python dependencies..."
pip install -r requirements_pi.txt || true

echo "[5/6] Checking ncnn import..."
python - <<'PY'
try:
    import ncnn
    print('[OK] ncnn Python package imports successfully:', ncnn)
except Exception as e:
    print('[WARN] ncnn Python package import failed:', repr(e))
    print('You may need to build ncnn with Python bindings on Raspberry Pi.')
    print('See README_RPI5_INT8.md troubleshooting section.')
PY

echo "[6/6] Done. Activate with:"
echo "source $PROJECT_DIR/.venv/bin/activate"
echo "Then verify model with:"
echo "python run_int8.py verify --param model.ncnn.param --bin model.ncnn.bin --table model_int8.table --imgsz 512"
