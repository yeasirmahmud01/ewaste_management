IMPORTANT: 512 package model files

This package contains the Raspberry Pi runner scripts patched for imgsz=512.

Copy these THREE files from your Kaggle 512 INT8 output into this folder before running on Raspberry Pi:

1. model.ncnn.param
2. model.ncnn.bin
3. model_int8.table

Do NOT use the old 704 model files with these 512 scripts.
The expected 512 YOLO output anchor count is 5376 = 64*64 + 32*32 + 16*16.
