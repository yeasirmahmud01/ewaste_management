#!/usr/bin/env python3
"""
run_int8.py
Unified runner for YOLO INT8 NCNN inference on Raspberry Pi 5.

Subcommands:
    verify   - sanity-check model loads and parsing works
    image    - run on a single image, save annotated output
    bulk     - benchmark on many images at multiple bulk sizes
    live     - live USB / Picamera2 demo
"""
from __future__ import annotations

import argparse
import csv
import gc
import json
import platform
import sys
import time
from collections import Counter, deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

HERE = Path(__file__).parent.resolve()
sys.path.insert(0, str(HERE))
from utils_ncnn_yolo import (  # noqa: E402
    NCNNDetector,
    CLASS_NAMES,
    NUM_CLASSES,
    CLASS_COLORS,
    cpu_percent_nonblocking,
    cpu_temp_c,
    draw_detections,
    draw_hud,
    list_images,
    parse_ncnn_param,
    ram_percent,
    summarize_latencies,
)


def safe_make_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def env_info() -> Dict[str, Any]:
    info = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor() or "n/a",
        "node": platform.node(),
    }
    model_path = Path("/sys/firmware/devicetree/base/model")
    if model_path.exists():
        try:
            info["device_model"] = model_path.read_text().strip("\x00 \n")
        except Exception:
            pass
    return info


def log_table_provenance(args) -> Optional[Dict[str, Any]]:
    if not getattr(args, "table", None):
        return None
    p = Path(args.table)
    if not p.exists():
        print(f"[WARN] --table not found: {p}. Continuing because NCNN runtime usually does not load it.")
        return None
    print(f"[INFO] calibration table: {p} ({p.stat().st_size/1024:.1f} KB) — logged only, not loaded by runtime.")
    return {"table_path": str(p), "table_size_bytes": p.stat().st_size}


def make_detector(args) -> NCNNDetector:
    return NCNNDetector(
        param_path=args.param,
        bin_path=args.bin,
        imgsz=args.imgsz,
        num_threads=args.threads,
        use_vulkan=getattr(args, "vulkan", False),
        input_blob=getattr(args, "input_blob", "auto"),
        output_blob=getattr(args, "output_blob", "auto"),
    )


def _save_csv(rows: List[Dict[str, Any]], path: Path) -> None:
    if not rows:
        path.write_text("")
        return
    keys: List[str] = []
    for r in rows:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def _format_table(rows: List[Dict[str, Any]], cols: List[str]) -> str:
    if not rows:
        return "(no rows)"
    widths = {c: max(len(c), max(len(f"{r.get(c, ''):.2f}" if isinstance(r.get(c), float) else str(r.get(c, ""))) for r in rows)) for c in cols}
    head = " | ".join(c.ljust(widths[c]) for c in cols)
    sep = "-+-".join("-" * widths[c] for c in cols)
    lines = [head, sep]
    for r in rows:
        vals = []
        for c in cols:
            v = r.get(c, "")
            vals.append((f"{v:.2f}" if isinstance(v, float) else str(v)).ljust(widths[c]))
        lines.append(" | ".join(vals))
    return "\n".join(lines)


def save_plots(per_image: List[Dict[str, Any]], summary: List[Dict[str, Any]], out_dir: Path,
               detections_by_class: Counter, temps: List[Tuple[float, Optional[float]]],
               rams: List[Tuple[float, Optional[float]]], confidences: List[float], prefix: str = "") -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as e:
        print(f"[WARN] plotting disabled: {e}")
        return

    out_dir.mkdir(parents=True, exist_ok=True)

    def save(fig, name):
        for ext in ("png", "svg"):
            fig.savefig(out_dir / f"{prefix}{name}.{ext}", bbox_inches="tight", dpi=170)
        plt.close(fig)

    if summary:
        sizes = [r["bulk_size"] for r in summary]
        fig, ax = plt.subplots(figsize=(6.4, 4.0))
        ax.plot(sizes, [r["fps_mean"] for r in summary], marker="o")
        ax.set_xlabel("Bulk size (images)"); ax.set_ylabel("Average FPS")
        ax.set_title("FPS vs bulk size"); ax.grid(True, alpha=0.3)
        save(fig, "fps_vs_bulk_size")

        fig, ax = plt.subplots(figsize=(6.4, 4.0))
        ax.plot(sizes, [r["latency_mean_ms"] for r in summary], marker="o")
        ax.set_xlabel("Bulk size (images)"); ax.set_ylabel("Average latency (ms)")
        ax.set_title("Latency vs bulk size"); ax.grid(True, alpha=0.3)
        save(fig, "latency_vs_bulk_size")

        x = np.arange(len(sizes)); width = 0.2
        fig, ax = plt.subplots(figsize=(7.0, 4.0))
        for off, key, lab in [(-1.5, "latency_p50_ms", "p50"), (-0.5, "latency_p90_ms", "p90"), (0.5, "latency_p95_ms", "p95"), (1.5, "latency_p99_ms", "p99")]:
            ax.bar(x + off * width, [r[key] for r in summary], width, label=lab)
        ax.set_xticks(x); ax.set_xticklabels([str(s) for s in sizes])
        ax.set_xlabel("Bulk size"); ax.set_ylabel("Latency (ms)")
        ax.set_title("Latency percentiles"); ax.legend(); ax.grid(True, axis="y", alpha=0.3)
        save(fig, "latency_percentiles")

        pre = np.array([r["preprocess_mean_ms"] for r in summary])
        inf = np.array([r["inference_mean_ms"] for r in summary])
        post = np.array([r["postprocess_mean_ms"] for r in summary])
        fig, ax = plt.subplots(figsize=(7.0, 4.0))
        ax.bar(x, pre, label="preprocess")
        ax.bar(x, inf, bottom=pre, label="inference")
        ax.bar(x, post, bottom=pre + inf, label="postprocess")
        ax.set_xticks(x); ax.set_xticklabels([str(s) for s in sizes])
        ax.set_ylabel("Mean latency (ms)"); ax.set_xlabel("Bulk size")
        ax.set_title("Latency breakdown"); ax.legend(); ax.grid(True, axis="y", alpha=0.3)
        save(fig, "preprocess_inference_postprocess_breakdown")

    if per_image:
        counts = [r.get("n_detections", 0) for r in per_image]
        fig, ax = plt.subplots(figsize=(6.4, 4.0))
        ax.hist(counts, bins=max(10, min(60, max(counts) + 1)), edgecolor="black")
        ax.set_xlabel("Detections per image"); ax.set_ylabel("Frequency")
        ax.set_title("Detections per image"); ax.grid(True, alpha=0.3)
        save(fig, "detections_per_image_histogram")

    if detections_by_class:
        names = CLASS_NAMES
        vals = [detections_by_class.get(i, 0) for i in range(NUM_CLASSES)]
        fig, ax = plt.subplots(figsize=(6.4, 4.0))
        ax.bar(names, vals)
        ax.set_ylabel("Total detections"); ax.set_title("Detection counts per class")
        ax.tick_params(axis='x', rotation=20)
        ax.grid(True, axis="y", alpha=0.3)
        save(fig, "class_detection_counts")

    if confidences:
        fig, ax = plt.subplots(figsize=(6.4, 4.0))
        ax.hist(confidences, bins=30, edgecolor="black")
        ax.set_xlabel("Confidence"); ax.set_ylabel("Frequency")
        ax.set_title("Confidence distribution"); ax.grid(True, alpha=0.3)
        save(fig, "confidence_distribution")

    if temps and any(v is not None for _, v in temps):
        fig, ax = plt.subplots(figsize=(7.0, 3.5))
        ax.plot([x for x, _ in temps], [np.nan if y is None else y for _, y in temps])
        ax.set_xlabel("Time (s)"); ax.set_ylabel("CPU temperature (°C)")
        ax.set_title("CPU temperature over time"); ax.grid(True, alpha=0.3)
        save(fig, "cpu_temperature_over_time")

    if rams and any(v is not None for _, v in rams):
        fig, ax = plt.subplots(figsize=(7.0, 3.5))
        ax.plot([x for x, _ in rams], [np.nan if y is None else y for _, y in rams])
        ax.set_xlabel("Time (s)"); ax.set_ylabel("RAM usage (%)")
        ax.set_title("RAM usage over time"); ax.grid(True, alpha=0.3)
        save(fig, "ram_usage_over_time")


def cmd_verify(args) -> int:
    print("=" * 72)
    print("VERIFY MODE")
    print("=" * 72)
    for key in ("param", "bin"):
        p = Path(getattr(args, key))
        if not p.exists():
            print(f"[FATAL] missing --{key}: {p}")
            return 2
        print(f"{key:>8}: {p} ({p.stat().st_size/1e6:.2f} MB)")
    log_table_provenance(args)

    pinfo = parse_ncnn_param(args.param)
    print("\n[PARAM INSPECTION]")
    print("Inputs       :", pinfo.get("inputs"))
    print("Outputs guess:", pinfo.get("outputs_guess"))
    print("Using input  :", args.input_blob)
    print("Using output :", args.output_blob)
    print("imgsz        :", args.imgsz)
    print("classes      :", NUM_CLASSES, CLASS_NAMES)

    det = make_detector(args)
    print("Resolved input blob :", det.input_blob)
    print("Resolved output blob:", det.output_blob)

    dummy = np.full((args.imgsz, args.imgsz, 3), 114, dtype=np.uint8)
    dets, timing = det.infer(dummy, conf_thresh=0.001, iou_thresh=0.45)
    print("\n[DUMMY INFERENCE]")
    print(f"pre={timing['preprocess_ms']:.2f} ms inf={timing['inference_ms']:.2f} ms post={timing['postprocess_ms']:.2f} ms total={timing['total_ms']:.2f} ms")
    print("detections at low conf on gray image:", len(dets))

    # Raw output shape check
    mat, _, _, _ = det._preprocess(dummy)
    ex = det.net.create_extractor(); ex.input(det.input_blob, mat)
    ret, out = ex.extract(det.output_blob)
    if ret != 0:
        print(f"[FATAL] raw extract failed ret={ret}")
        return 3
    raw = np.array(out)
    print("raw output shape:", raw.shape, "dtype:", raw.dtype)
    flat = int(np.prod(raw.shape))
    ch = 4 + NUM_CLASSES
    if flat % ch == 0:
        anchors = flat // ch
        print(f"anchors implied: {anchors} (flat={flat}, channels={ch})")
        if args.imgsz == 704 and anchors != 5376:
            print("[WARN] imgsz=512 usually implies 5376 anchors for this export.")
        if args.imgsz == 640 and anchors != 8400:
            print("[WARN] imgsz=640 usually implies 8400 anchors for YOLO export.")
    else:
        print(f"[WARN] flat output {flat} not divisible by {ch}")

    rng = np.random.default_rng(0)
    fake = rng.integers(0, 255, (args.imgsz, args.imgsz, 3), dtype=np.uint8)
    dets, timing = det.infer(fake, conf_thresh=0.25, iou_thresh=0.45)
    print(f"random image total={timing['total_ms']:.2f} ms kept={len(dets)} dets")
    print("\n=== VERIFY: READY ===")
    return 0


def cmd_image(args) -> int:
    img_path = Path(args.image)
    img = cv2.imread(str(img_path))
    if img is None:
        print(f"[FATAL] Could not read image: {img_path}")
        return 2
    det = make_detector(args); log_table_provenance(args)
    for _ in range(max(0, args.warmup)):
        _ = det.infer(img, conf_thresh=args.conf, iou_thresh=args.iou)
    dets, timing = det.infer(img, conf_thresh=args.conf, iou_thresh=args.iou)
    print(f"detections: {len(dets)}")
    for d in dets[:30]:
        print(f"  {d['class_name']:15s} score={d['score']:.3f} bbox={[round(v,1) for v in d['bbox']]}")
    print("Latency ms:", {k: round(v, 2) for k, v in timing.items()}, "FPS", round(1000.0 / max(timing['total_ms'], 1e-6), 2))
    if args.save:
        out_dir = safe_make_dir(Path(args.out_dir) if args.out_dir else HERE / "demo_outputs")
        ann = draw_detections(img, dets)
        out_img = out_dir / f"{img_path.stem}_det.jpg"
        out_json = out_dir / f"{img_path.stem}_det.json"
        cv2.imwrite(str(out_img), ann)
        out_json.write_text(json.dumps({"image": str(img_path), "detections": dets, "timing_ms": timing}, indent=2))
        print("saved:", out_img)
        print("saved:", out_json)
    return 0


def cmd_bulk(args) -> int:
    imgs = list_images(args.source, recursive=args.recursive)
    if not imgs:
        print(f"[FATAL] no images found: {args.source}")
        return 2
    if args.shuffle:
        rng = np.random.default_rng(args.seed)
        imgs = list(np.array(imgs)[rng.permutation(len(imgs))])
    out_root = safe_make_dir(Path(args.out_dir) if args.out_dir else HERE / "benchmark_outputs")
    det = make_detector(args); table_meta = log_table_provenance(args)

    print(f"[INFO] found {len(imgs)} images. bulk sizes={args.bulk_sizes} imgsz={args.imgsz} threads={args.threads}")
    if args.warmup > 0:
        im = cv2.imread(str(imgs[0]))
        if im is not None:
            print(f"[INFO] warmup x{args.warmup}")
            for _ in range(args.warmup):
                _ = det.infer(im, conf_thresh=args.conf, iou_thresh=args.iou)
    cpu_percent_nonblocking()

    summary_rows: List[Dict[str, Any]] = []
    all_rows: List[Dict[str, Any]] = []
    detections_by_class: Counter = Counter()
    confidences: List[float] = []
    temps: List[Tuple[float, Optional[float]]] = []
    rams: List[Tuple[float, Optional[float]]] = []
    start = time.perf_counter()
    breaking_size = None; breaking_reason = None

    for bulk_size in sorted(set(args.bulk_sizes)):
        size_dir = safe_make_dir(out_root / f"bulk_{bulk_size}")
        ann_dir = safe_make_dir(size_dir / "annotated_samples") if args.save_annotated else None
        pred_dir = safe_make_dir(size_dir / "predictions") if args.save_predictions else None
        pool = imgs[:bulk_size] if len(imgs) >= bulk_size else [imgs[i % len(imgs)] for i in range(bulk_size)]
        looped = len(imgs) < bulk_size
        if looped:
            print(f"[INFO] bulk {bulk_size}: using repeated images because only {len(imgs)} unique images exist")

        rows: List[Dict[str, Any]] = []
        errors = 0; saved_ann = 0
        wall0 = time.perf_counter()
        for i, p in enumerate(pool):
            im = cv2.imread(str(p))
            if im is None:
                errors += 1; continue
            try:
                dets, timing = det.infer(im, conf_thresh=args.conf, iou_thresh=args.iou)
            except Exception as e:
                errors += 1
                print(f"[WARN] inference failed on {p}: {e}")
                if errors > max(10, bulk_size // 20):
                    breaking_size = bulk_size; breaking_reason = f"too many errors ({errors})"
                    break
                continue
            for d in dets:
                detections_by_class[int(d["class_id"])] += 1
                confidences.append(float(d["score"]))
            row = {
                "bulk_size": bulk_size,
                "image": str(p),
                "preprocess_ms": round(timing["preprocess_ms"], 3),
                "inference_ms": round(timing["inference_ms"], 3),
                "postprocess_ms": round(timing["postprocess_ms"], 3),
                "total_ms": round(timing["total_ms"], 3),
                "n_detections": len(dets),
            }
            rows.append(row); all_rows.append(row)
            if ann_dir is not None and saved_ann < args.max_save_annotated:
                cv2.imwrite(str(ann_dir / f"{i:05d}_{Path(p).stem}.jpg"), draw_detections(im, dets)); saved_ann += 1
            if pred_dir is not None:
                (pred_dir / f"{i:05d}_{Path(p).stem}.json").write_text(json.dumps({"image": str(p), "detections": dets, "timing_ms": timing}, indent=2))
            if i % 25 == 0:
                t = time.perf_counter() - start
                temps.append((t, cpu_temp_c())); rams.append((t, ram_percent()))
        wall = time.perf_counter() - wall0
        if not rows:
            continue
        totals = [r["total_ms"] for r in rows]
        pre = [r["preprocess_ms"] for r in rows]
        inf = [r["inference_ms"] for r in rows]
        post = [r["postprocess_ms"] for r in rows]
        st = summarize_latencies(totals); st_pre = summarize_latencies(pre); st_inf = summarize_latencies(inf); st_post = summarize_latencies(post)
        summary = {
            "bulk_size": bulk_size,
            "n_completed": len(rows),
            "errors": errors,
            "looped_images": looped,
            "wall_seconds": round(wall, 3),
            "throughput_fps": round(len(rows) / max(wall, 1e-9), 2),
            "fps_mean": round(1000.0 / max(st["mean"], 1e-9), 2),
            "latency_mean_ms": round(st["mean"], 2),
            "latency_median_ms": round(st["median"], 2),
            "latency_p50_ms": round(st["p50"], 2),
            "latency_p90_ms": round(st["p90"], 2),
            "latency_p95_ms": round(st["p95"], 2),
            "latency_p99_ms": round(st["p99"], 2),
            "latency_min_ms": round(st["min"], 2),
            "latency_max_ms": round(st["max"], 2),
            "latency_std_ms": round(st["std"], 2),
            "preprocess_mean_ms": round(st_pre["mean"], 2),
            "inference_mean_ms": round(st_inf["mean"], 2),
            "postprocess_mean_ms": round(st_post["mean"], 2),
            "ram_percent_end": None if ram_percent() is None else round(ram_percent(), 1),
            "cpu_temp_c_end": None if cpu_temp_c() is None else round(cpu_temp_c(), 1),
            "cpu_percent_end": None if cpu_percent_nonblocking() is None else round(cpu_percent_nonblocking(), 1),
        }
        summary_rows.append(summary)
        _save_csv(rows, size_dir / "per_image_results.csv")
        (size_dir / "summary.json").write_text(json.dumps(summary, indent=2))
        print(f"bulk={bulk_size:5d} N={len(rows):5d} avg={summary['latency_mean_ms']:7.2f}ms p95={summary['latency_p95_ms']:7.2f}ms fps={summary['fps_mean']:7.2f} ram={summary['ram_percent_end']} temp={summary['cpu_temp_c_end']}")

        if breaking_size is None:
            reasons = []
            if summary["fps_mean"] < args.fps_threshold: reasons.append(f"fps {summary['fps_mean']} < {args.fps_threshold}")
            if summary["latency_p95_ms"] > args.latency_threshold_ms: reasons.append(f"p95 {summary['latency_p95_ms']} > {args.latency_threshold_ms}")
            if summary["cpu_temp_c_end"] is not None and summary["cpu_temp_c_end"] > args.temp_threshold_c: reasons.append(f"temp {summary['cpu_temp_c_end']} > {args.temp_threshold_c}")
            if summary["ram_percent_end"] is not None and summary["ram_percent_end"] > args.ram_threshold_percent: reasons.append(f"ram {summary['ram_percent_end']} > {args.ram_threshold_percent}")
            if reasons:
                breaking_size = bulk_size; breaking_reason = "; ".join(reasons)
        gc.collect()

    _save_csv(summary_rows, out_root / "benchmark_summary.csv")
    _save_csv(all_rows, out_root / "benchmark_per_image.csv")
    (out_root / "benchmark_summary.json").write_text(json.dumps({
        "env": env_info(), "args": vars(args), "table_provenance": table_meta,
        "per_size_summaries": summary_rows,
        "detections_by_class": {CLASS_NAMES[k]: int(v) for k, v in detections_by_class.items()},
        "breaking_size": breaking_size, "breaking_reason": breaking_reason,
    }, indent=2, default=str))
    if args.save_plots:
        save_plots(all_rows, summary_rows, out_root, detections_by_class, temps, rams, confidences)

    print("\n" + "=" * 72)
    print("BULK BENCHMARK SUMMARY")
    print("=" * 72)
    print(f"Backend: NCNN INT8 | Device: {env_info().get('device_model', 'unknown')} | Threads: {args.threads} | imgsz: {args.imgsz}")
    print(_format_table(summary_rows, ["bulk_size", "latency_mean_ms", "latency_p95_ms", "fps_mean", "ram_percent_end", "cpu_temp_c_end"]))
    print("Breaking point:", breaking_size if breaking_size is not None else "not reached", breaking_reason or "")
    print("Results:", out_root)
    return 0


class FrameSource:
    def __init__(self, args):
        self.kind = "picam" if args.picamera else "cv"
        self.width, self.height = args.width, args.height
        self._cap = None; self._picam = None
        if self.kind == "picam":
            try:
                from picamera2 import Picamera2  # type: ignore
            except ImportError as e:
                raise RuntimeError("Picamera2 not installed. Try: sudo apt install -y python3-picamera2") from e
            self._picam = Picamera2()
            config = self._picam.create_video_configuration(main={"size": (self.width, self.height), "format": "RGB888"})
            self._picam.configure(config); self._picam.start(); time.sleep(0.5)
        else:
            self._cap = cv2.VideoCapture(int(args.camera))
            if not self._cap.isOpened():
                raise RuntimeError(f"could not open camera index {args.camera}")
            self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)

    def read(self) -> Optional[np.ndarray]:
        if self.kind == "picam":
            arr = self._picam.capture_array()
            if arr is None: return None
            return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
        ok, frame = self._cap.read()
        return frame if ok else None

    def close(self) -> None:
        if self._cap is not None: self._cap.release()
        if self._picam is not None:
            try: self._picam.stop()
            except Exception: pass


def cmd_live(args) -> int:
    out_dir = safe_make_dir(Path(args.out_dir) if args.out_dir else HERE / "live_outputs")
    snap_dir = safe_make_dir(out_dir / "snapshots")
    det = make_detector(args); log_table_provenance(args)
    src = FrameSource(args)
    cpu_percent_nonblocking()
    display_ok = bool(args.display) and not bool(args.headless)
    if display_ok:
        try: cv2.namedWindow("plastic_detect", cv2.WINDOW_NORMAL)
        except Exception as e:
            print("[WARN] display unavailable, switching to headless:", e); display_ok = False

    writer = None; video_path = out_dir / "live_recording.mp4" if args.save_video else None
    fps_window = deque(maxlen=30); lat_window = deque(maxlen=120)
    rows: List[Dict[str, Any]] = []
    det_counts: Counter = Counter()
    start = time.perf_counter(); frame_idx = 0; paused = False
    print("[INFO] live started. q=quit, s=snapshot, p=pause")
    try:
        while True:
            now = time.perf_counter() - start
            if args.duration and now >= args.duration: break
            if args.max_frames and frame_idx >= args.max_frames: break
            frame = src.read()
            if frame is None:
                print("[WARN] camera returned no frame"); break
            if not paused:
                dets, timing = det.infer(frame, conf_thresh=args.conf, iou_thresh=args.iou)
                for d in dets: det_counts[int(d["class_id"])] += 1
                lat = timing["total_ms"]; lat_window.append(lat); fps_window.append(1000.0 / max(lat, 1e-9))
                fps_inst = fps_window[-1]; fps_avg = float(np.mean(fps_window)); p95 = float(np.percentile(lat_window, 95))
                temp = cpu_temp_c(); ram = ram_percent(); cpu = cpu_percent_nonblocking()
                row = {
                    "t_seconds": round(now, 3), "frame": frame_idx,
                    "preprocess_ms": round(timing["preprocess_ms"], 2), "inference_ms": round(timing["inference_ms"], 2),
                    "postprocess_ms": round(timing["postprocess_ms"], 2), "total_ms": round(lat, 2),
                    "fps_inst": round(fps_inst, 2), "fps_avg": round(fps_avg, 2), "p95_ms": round(p95, 2),
                    "n_detections": len(dets), "cpu_temp_c": None if temp is None else round(temp, 1),
                    "ram_percent": None if ram is None else round(ram, 1), "cpu_percent": None if cpu is None else round(cpu, 1),
                }
                rows.append(row)
                disp = draw_detections(frame, dets)
                hud = [
                    f"FPS {fps_inst:.1f} avg {fps_avg:.1f}",
                    f"lat {lat:.1f} ms inf {timing['inference_ms']:.1f} ms",
                    f"dets {len(dets)} conf>={args.conf:.2f}",
                    f"{args.model_name} imgsz={args.imgsz}",
                ]
                if temp is not None: hud.append(f"CPU temp {temp:.1f} C")
                if ram is not None: hud.append(f"RAM {ram:.1f}%")
                disp = draw_hud(disp, hud)
                if writer is None and video_path is not None:
                    h, w = disp.shape[:2]
                    writer = cv2.VideoWriter(str(video_path), cv2.VideoWriter_fourcc(*"mp4v"), 15, (w, h))
                if writer is not None: writer.write(disp)
            else:
                disp = draw_hud(frame.copy(), ["PAUSED - press p to resume"])

            if display_ok:
                cv2.imshow("plastic_detect", disp)
                k = cv2.waitKey(1) & 0xFF
                if k == ord("q"): break
                if k == ord("s"):
                    out = snap_dir / f"frame_{frame_idx:06d}.jpg"; cv2.imwrite(str(out), disp); print("saved", out)
                if k == ord("p"):
                    paused = not paused; print("paused" if paused else "resumed")
            elif frame_idx % 30 == 0 and rows:
                r = rows[-1]
                print(f"frame={frame_idx} fps={r['fps_avg']} lat={r['total_ms']}ms dets={r['n_detections']}")
            frame_idx += 1
    except KeyboardInterrupt:
        print("[INFO] interrupted")
    finally:
        if writer is not None: writer.release()
        if display_ok:
            try: cv2.destroyAllWindows()
            except Exception: pass
        src.close()

    if not rows:
        print("[WARN] no frames processed")
        return 0
    _save_csv(rows, out_dir / "live_log.csv")
    totals = [r["total_ms"] for r in rows]; st = summarize_latencies(totals)
    summary = {
        "frames": len(rows), "duration_s": round(rows[-1]["t_seconds"], 2),
        "fps_mean": round(float(np.mean([r["fps_avg"] for r in rows])), 2),
        "fps_median": round(float(np.median([r["fps_avg"] for r in rows])), 2),
        "latency_mean_ms": round(st["mean"], 2), "latency_p95_ms": round(st["p95"], 2),
        "max_cpu_temp_c": max([r["cpu_temp_c"] for r in rows if r["cpu_temp_c"] is not None], default=None),
        "ram_percent_avg": round(float(np.mean([r["ram_percent"] for r in rows if r["ram_percent"] is not None] or [0])), 1),
        "total_detections": int(sum(r["n_detections"] for r in rows)),
        "detections_by_class": {CLASS_NAMES[k]: int(v) for k, v in det_counts.items()},
        "most_frequent_class": CLASS_NAMES[max(det_counts, key=det_counts.get)] if det_counts else None,
    }
    (out_dir / "live_summary.json").write_text(json.dumps(summary, indent=2))
    save_plots(rows, [], out_dir, det_counts, [(r["t_seconds"], r["cpu_temp_c"]) for r in rows], [(r["t_seconds"], r["ram_percent"]) for r in rows], [], prefix="live_")
    # specific live plots
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        xs = [r["t_seconds"] for r in rows]
        for key, ylabel, name in [("fps_avg", "FPS", "live_fps_over_time"), ("total_ms", "Latency (ms)", "live_latency_over_time")]:
            fig, ax = plt.subplots(figsize=(7, 3.5)); ax.plot(xs, [r[key] for r in rows])
            ax.set_xlabel("Time (s)"); ax.set_ylabel(ylabel); ax.set_title(name.replace("_", " ")); ax.grid(True, alpha=0.3)
            for ext in ("png", "svg"): fig.savefig(out_dir / f"{name}.{ext}", bbox_inches="tight", dpi=170)
            plt.close(fig)
    except Exception: pass
    print("\n=== LIVE SUMMARY ===")
    for k, v in summary.items(): print(f"{k:22s}: {v}")
    print("Results:", out_dir)
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="YOLO INT8 NCNN runner for Raspberry Pi 5", formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--param", required=True, help="model.ncnn.param")
        sp.add_argument("--bin", required=True, help="model.ncnn.bin")
        sp.add_argument("--table", default=None, help="optional model_int8.table, logged only")
        sp.add_argument("--imgsz", type=int, default=512, help="input size used by export, likely 512 for this model")
        sp.add_argument("--threads", type=int, default=4)
        sp.add_argument("--vulkan", action="store_true", help="enable Vulkan if NCNN build supports it")
        sp.add_argument("--input-blob", default="auto", help="input blob name or auto")
        sp.add_argument("--output-blob", default="auto", help="output blob name or auto")
        sp.add_argument("--model-name", default="YOLO11s INT8 NCNN 512")

    sp = sub.add_parser("verify", help="sanity check model and parser"); common(sp); sp.set_defaults(func=cmd_verify)

    sp = sub.add_parser("image", help="single image inference"); common(sp)
    sp.add_argument("--image", required=True); sp.add_argument("--conf", type=float, default=0.25); sp.add_argument("--iou", type=float, default=0.45)
    sp.add_argument("--warmup", type=int, default=2); sp.add_argument("--save", action="store_true"); sp.add_argument("--out-dir", default=None)
    sp.set_defaults(func=cmd_image)

    sp = sub.add_parser("bulk", help="bulk benchmark"); common(sp)
    sp.add_argument("--source", required=True); sp.add_argument("--recursive", action="store_true"); sp.add_argument("--shuffle", action="store_true"); sp.add_argument("--seed", type=int, default=42)
    sp.add_argument("--bulk-sizes", type=int, nargs="+", default=[10, 100, 500, 1000]); sp.add_argument("--warmup", type=int, default=10)
    sp.add_argument("--conf", type=float, default=0.25); sp.add_argument("--iou", type=float, default=0.45)
    sp.add_argument("--save-plots", action="store_true"); sp.add_argument("--save-annotated", action="store_true"); sp.add_argument("--save-predictions", action="store_true")
    sp.add_argument("--max-save-annotated", type=int, default=50); sp.add_argument("--fps-threshold", type=float, default=10.0)
    sp.add_argument("--latency-threshold-ms", type=float, default=150.0); sp.add_argument("--temp-threshold-c", type=float, default=80.0); sp.add_argument("--ram-threshold-percent", type=float, default=85.0)
    sp.add_argument("--out-dir", default=None); sp.set_defaults(func=cmd_bulk)

    sp = sub.add_parser("live", help="live camera inference"); common(sp)
    grp = sp.add_mutually_exclusive_group(); grp.add_argument("--camera", type=int, default=0); grp.add_argument("--picamera", action="store_true")
    sp.add_argument("--width", type=int, default=1280); sp.add_argument("--height", type=int, default=720)
    sp.add_argument("--conf", type=float, default=0.25); sp.add_argument("--iou", type=float, default=0.45)
    sp.add_argument("--display", action="store_true"); sp.add_argument("--headless", action="store_true"); sp.add_argument("--save-video", action="store_true")
    sp.add_argument("--duration", type=float, default=0); sp.add_argument("--max-frames", type=int, default=0); sp.add_argument("--out-dir", default=None)
    sp.set_defaults(func=cmd_live)
    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser(); args = parser.parse_args(argv)
    if getattr(args, "cmd", None) == "live" and not args.display and not args.headless:
        args.display = True
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\n[INFO] interrupted"); return 130
    except Exception:
        import traceback; traceback.print_exc(); return 1


if __name__ == "__main__":
    sys.exit(main())
